package at.fhtw.tourplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
